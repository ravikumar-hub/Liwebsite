﻿#requires -Version 5.1
#requires -RunAsAdministrator
<#
.SYNOPSIS
  Windows 11 performance profile with a clean console interface and reversible settings.

.DESCRIPTION
  Applies a reversible set of gaming, background-content, privacy, storage,
  and Windows Power Throttling registry setting.

  CPU safety note: this does NOT disable Intel thermal throttling, PL1/PL2,
  PROCHOT/BD PROCHOT, or firmware thermal/electrical protections.

  Includes the Explorer/Start/taskbar preference tweaks from the earlier
  65-value profile, plus the additional Explorer, MMCSS, CPU/memory, GPU TDR,
  and TCP tweaks from the 33-value profile.

  Explicitly does NOT change:
    - Display brightness, display timeout, sleep, or hibernate settings
    - Windows animations, visual effects, DWM, transparency, or shadows
    - Windows Defender, Firewall, Windows Update, or core services
    - Pagefile size/placement or Windows service startup configuration

  MMCSS, CPU scheduling, GPU TDR, and TCP changes are experimental and are
  not guaranteed to improve FPS, latency, or benchmark scores.

  Always creates a backup before applying. Access-denied values are skipped;
  other failures trigger automatic rollback. Immediately after applying, the
  script verifies every selected registry value and displays before/after
  results, then asks whether to restart. After Windows starts again, run with
  -Verify for a second verification pass.
#>

[CmdletBinding()]
param(
    [switch]$PreviewOnly,
    [switch]$Rollback,
    [switch]$Verify,
    [switch]$Force,
    [switch]$SkipTdrAndTcp,
    [switch]$SkipExperimentalScheduler,
    [switch]$DetailedOutput
)

$ErrorActionPreference = 'Stop'
$ProfileName = 'Win11-Aggressive-Registry-Performance-Full'
$BackupRoot = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Win11-Aggressive-Performance-Backups'

function Write-Section {
    param([string]$Title)
    Write-Host ''
    Write-Host ("  > {0}" -f $Title) -ForegroundColor Cyan
    Write-Host ("    " + ([string][char]0x2500 * 54)) -ForegroundColor DarkGray
}

function Write-Banner {
    Clear-Host
    Write-Host ''
    Write-Host '  +----------------------------------------------------------+' -ForegroundColor DarkCyan
    Write-Host '  |              WINDOWS 11 PERFORMANCE                     |' -ForegroundColor Cyan
    Write-Host '  |          PERFORMANCE  /  PRIVACY  /  CONTROL             |' -ForegroundColor Gray
    Write-Host '  +----------------------------------------------------------+' -ForegroundColor DarkCyan
    Write-Host ''
}

function Write-Status {
    param(
        [string]$Label,
        [string]$Value,
        [ConsoleColor]$Color = [ConsoleColor]::Gray
    )
    Write-Host ("  {0,-25}" -f $Label) -NoNewline -ForegroundColor DarkGray
    Write-Host $Value -ForegroundColor $Color
}

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Format-Value {
    param($Value)
    if ($null -eq $Value) { return '<not present>' }
    if ($Value -is [array]) { return ($Value -join ', ') }
    return [string]$Value
}

function Get-RegistrySnapshot {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$Name
    )

    try {
        $key = Get-Item -LiteralPath $Path -ErrorAction Stop
    }
    catch {
        $message = [string]$_.Exception.Message
        if ($_.CategoryInfo.Category -eq [System.Management.Automation.ErrorCategory]::ObjectNotFound -or
            $message -match '(?i)cannot find path|path does not exist|cannot find drive') {
            return [pscustomobject]@{
                Path = $Path; Name = $Name; Existed = $false; Kind = $null; Value = $null
            }
        }
        throw
    }

    if ($key.GetValueNames() -notcontains $Name) {
        return [pscustomobject]@{
            Path = $Path; Name = $Name; Existed = $false; Kind = $null; Value = $null
        }
    }

    $kind = $key.GetValueKind($Name).ToString()
    $value = $key.GetValue(
        $Name,
        $null,
        [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames
    )

    if ($kind -eq 'Binary' -or $kind -eq 'None') {
        $value = [Convert]::ToBase64String([byte[]]$value)
    }

    [pscustomobject]@{
        Path = $Path; Name = $Name; Existed = $true; Kind = $kind; Value = $value
    }
}

function Set-RegistryValue {
    param([Parameter(Mandatory)]$Change)

    if (-not (Test-Path -LiteralPath $Change.Path)) {
        New-Item -Path $Change.Path -Force -ErrorAction Stop | Out-Null
    }

    New-ItemProperty -LiteralPath $Change.Path -Name $Change.Name `
        -PropertyType $Change.Kind -Value $Change.Value -Force -ErrorAction Stop | Out-Null

    $key = Get-Item -LiteralPath $Change.Path -ErrorAction Stop
    $actual = $key.GetValue(
        $Change.Name,
        $null,
        [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames
    )
    if ([string]$actual -cne [string]$Change.Value) {
        throw "Verification failed for $($Change.Path)\$($Change.Name): expected '$($Change.Value)', got '$actual'."
    }
}

function Restore-RegistrySnapshot {
    param([Parameter(Mandatory)]$Snapshot)

    if ($Snapshot.Existed) {
        if (-not (Test-Path -LiteralPath $Snapshot.Path)) {
            New-Item -Path $Snapshot.Path -Force -ErrorAction Stop | Out-Null
        }

        $restoreValue = $Snapshot.Value
        switch ($Snapshot.Kind) {
            'Binary' { $restoreValue = [Convert]::FromBase64String([string]$Snapshot.Value) }
            'None'   { $restoreValue = [Convert]::FromBase64String([string]$Snapshot.Value) }
            'DWord'  { $restoreValue = [int]$Snapshot.Value }
            'QWord'  { $restoreValue = [long]$Snapshot.Value }
        }

        New-ItemProperty -LiteralPath $Snapshot.Path -Name $Snapshot.Name `
            -PropertyType $Snapshot.Kind -Value $restoreValue -Force -ErrorAction Stop | Out-Null
    }
    elseif (Test-Path -LiteralPath $Snapshot.Path) {
        Remove-ItemProperty -LiteralPath $Snapshot.Path -Name $Snapshot.Name -ErrorAction SilentlyContinue
    }
}

function Get-TcpGlobalState {
    $output = & netsh.exe int tcp show global 2>&1
    if ($LASTEXITCODE -ne 0) { return $null }
    $joined = $output -join "`n"
    $rss = [regex]::Match($joined, '(?im)^\s*Receive-Side Scaling State\s*:\s*(enabled|disabled)')
    $auto = [regex]::Match($joined, '(?im)^\s*Receive Window Auto-Tuning Level\s*:\s*(disabled|highlyrestricted|restricted|normal|experimental)')
    if (-not $rss.Success -or -not $auto.Success) { return $null }
    [pscustomobject]@{
        RSS = $rss.Groups[1].Value.ToLowerInvariant()
        AutoTuning = $auto.Groups[1].Value.ToLowerInvariant()
    }
}

function Set-TcpGlobalState {
    param([Parameter(Mandatory)]$State)
    & netsh.exe int tcp set global ("rss={0}" -f $State.RSS) | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Could not set TCP Receive-Side Scaling to $($State.RSS)." }
    & netsh.exe int tcp set global ("autotuninglevel={0}" -f $State.AutoTuning) | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Could not set TCP auto-tuning to $($State.AutoTuning)." }
}

$script:ProcessorPowerSubgroupGuid = '54533251-82be-4824-96c1-47b60b740d00'
$script:ProcessorPowerSettings = @(
    [pscustomobject]@{ Alias='CPMINCORES'; Guid='0cc5b647-c1df-4637-891a-dec35c318583' }
    [pscustomobject]@{ Alias='CPMAXCORES'; Guid='ea062031-0e34-4ff1-9b6d-eb1059334028' }
    [pscustomobject]@{ Alias='PERFBOOSTMODE'; Guid='be337238-0d82-4146-a960-4f3749d470c7' }
)

function Get-PowerCfgState {
    $active = & powercfg.exe /getactivescheme 2>&1
    if ($LASTEXITCODE -ne 0) { throw 'Could not read the active Windows power scheme.' }
    $schemeMatch = [regex]::Match(($active -join "`n"), '(?i)([0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12})')
    if (-not $schemeMatch.Success) { throw 'Could not identify the active Windows power scheme GUID.' }
    $scheme = $schemeMatch.Groups[1].Value

    $boost = & powercfg.exe /qh $scheme SUB_PROCESSOR PERFBOOSTMODE 2>&1
    if ($LASTEXITCODE -ne 0) { throw 'Could not read the current processor boost mode.' }
    $boostText = $boost -join "`n"
    $acMatch = [regex]::Match($boostText, '(?im)^\s*Current AC Power Setting Index:\s*0x([0-9a-f]+)')
    $dcMatch = [regex]::Match($boostText, '(?im)^\s*Current DC Power Setting Index:\s*0x([0-9a-f]+)')
    if (-not $acMatch.Success -or -not $dcMatch.Success) {
        throw 'Could not parse the current AC/DC processor boost values.'
    }

    $attributeStates = @()
    foreach ($setting in $script:ProcessorPowerSettings) {
        $keyPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\$($script:ProcessorPowerSubgroupGuid)\$($setting.Guid)"
        $settingKey = Get-ItemProperty -LiteralPath $keyPath -Name Attributes -ErrorAction Stop
        $attributesValue = [int]$settingKey.Attributes
        $attributeStates += [pscustomobject]@{
            Alias = $setting.Alias
            Guid = $setting.Guid
            AttributesValue = $attributesValue
            Hidden = (($attributesValue -band 1) -ne 0)
        }
    }

    [pscustomobject]@{
        Scheme = $scheme
        AcBoostMode = [Convert]::ToInt32($acMatch.Groups[1].Value, 16)
        DcBoostMode = [Convert]::ToInt32($dcMatch.Groups[1].Value, 16)
        Attributes = @($attributeStates)
    }
}

function Set-PowerCfgState {
    param([Parameter(Mandatory)]$State)
    & powercfg.exe /setacvalueindex $State.Scheme SUB_PROCESSOR PERFBOOSTMODE ([string]$State.AcBoostMode) | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Could not restore the AC processor boost mode.' }
    & powercfg.exe /setdcvalueindex $State.Scheme SUB_PROCESSOR PERFBOOSTMODE ([string]$State.DcBoostMode) | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Could not restore the DC processor boost mode.' }

    foreach ($item in @($State.Attributes)) {
        # Older backup files only recorded a visibility Boolean. Do not apply
        # that unreliable legacy detection; restore exact DWORDs when available.
        if ($item.PSObject.Properties.Name -contains 'AttributesValue') {
            $keyPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\$($script:ProcessorPowerSubgroupGuid)\$($item.Guid)"
            Set-ItemProperty -LiteralPath $keyPath -Name Attributes -Value ([int]$item.AttributesValue) -ErrorAction Stop
        }
    }
    & powercfg.exe /setactive $State.Scheme | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Could not reactivate the restored power scheme.' }
}

function Set-RequestedPowerBoostProfile {
    & powercfg.exe /setacvalueindex SCHEME_CURRENT SUB_PROCESSOR PERFBOOSTMODE 2 | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Failed to set AC processor boost mode to Aggressive (2).' }
    & powercfg.exe /setdcvalueindex SCHEME_CURRENT SUB_PROCESSOR PERFBOOSTMODE 2 | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Failed to set DC processor boost mode to Aggressive (2).' }

    foreach ($setting in $script:ProcessorPowerSettings) {
        $keyPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\$($script:ProcessorPowerSubgroupGuid)\$($setting.Guid)"
        $current = Get-ItemProperty -LiteralPath $keyPath -Name Attributes -ErrorAction Stop
        $newAttributes = ([int]$current.Attributes -bor 1)
        Set-ItemProperty -LiteralPath $keyPath -Name Attributes -Value $newAttributes -ErrorAction Stop
    }

    & powercfg.exe /setactive SCHEME_CURRENT | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Failed to reapply the current power scheme.' }
}

# Rollback uses the newest matching baseline. The corrective rerun reuses the
# existing matching backup rather than replacing it with already-tweaked values.
function Get-LatestBackup {
    if (-not (Test-Path -LiteralPath $BackupRoot)) { return $null }

    Get-ChildItem -LiteralPath $BackupRoot -Directory |
        Where-Object {
            $marker = Join-Path $_.FullName 'ProfileName.txt'
            $state = Join-Path $_.FullName 'RegistryState.json'
            (Test-Path -LiteralPath $marker) -and
            (Test-Path -LiteralPath $state) -and
            ((Get-Content -LiteralPath $marker -Raw).Trim() -eq $ProfileName)
        } |
        Sort-Object Name -Descending |
        Select-Object -First 1
}

Write-Banner

$modeCount = 0
if ($PreviewOnly) { $modeCount++ }
if ($Rollback)    { $modeCount++ }
if ($Verify)      { $modeCount++ }
if ($modeCount -gt 1) {
    throw 'Use only one of -PreviewOnly, -Rollback, or -Verify.'
}
if (-not (Test-IsAdministrator)) {
    throw "Administrator privileges are required. Open PowerShell using 'Run as administrator'."
}

$os = Get-CimInstance -ClassName Win32_OperatingSystem
if ([int]$os.BuildNumber -lt 22000) {
    throw "Windows 11 is required. Detected $($os.Caption), build $($os.BuildNumber)."
}
Write-Status 'Operating system' $os.Caption Green
Write-Status 'Build' $os.BuildNumber
Write-Status 'Mode' $(if ($Rollback) { 'Rollback' } elseif ($Verify) { 'Post-reboot verification' } elseif ($PreviewOnly) { 'Preview only' } else { 'Apply profile' }) Cyan

# ------------------------------- ROLLBACK -----------------------------------
if ($Rollback) {
    Write-Section 'ROLLBACK'
    $backup = Get-LatestBackup
    if ($null -eq $backup) { throw "No backup for this profile was found in $BackupRoot" }

    $saved = @(Get-Content -LiteralPath (Join-Path $backup.FullName 'RegistryState.json') -Raw |
        ConvertFrom-Json)
    Write-Status 'Backup set' $backup.Name
    Write-Status 'Values to restore' $saved.Count

    $errors = @()
    for ($i = 0; $i -lt $saved.Count; $i++) {
        $item = $saved[$i]
        $percent = [int](($i + 1) * 100 / [math]::Max(1, $saved.Count))
        Write-Progress -Activity 'Restoring original registry settings' `
            -Status ("Restoring {0}/{1}" -f ($i + 1), $saved.Count) `
            -PercentComplete $percent
        try {
            Restore-RegistrySnapshot -Snapshot $item
            if ($DetailedOutput) {
                Write-Host ("  RESTORED  {0}" -f $item.Name) -ForegroundColor Green
            }
        }
        catch {
            $errors += ("{0}: {1}" -f $item.Name, $_.Exception.Message)
            Write-Host ("  FAILED  {0}: {1}" -f $item.Name, $_.Exception.Message) -ForegroundColor Red
        }
    }
    Write-Progress -Activity 'Restoring original registry settings' -Completed

    $networkStateFile = Join-Path $backup.FullName 'NetworkState.json'
    if (Test-Path -LiteralPath $networkStateFile) {
        try {
            $savedNetwork = Get-Content -LiteralPath $networkStateFile -Raw | ConvertFrom-Json
            if ($null -ne $savedNetwork.TcpGlobal) {
                Set-TcpGlobalState -State $savedNetwork.TcpGlobal
            }
            if ($null -ne $savedNetwork.PowerCfg) {
                Set-PowerCfgState -State $savedNetwork.PowerCfg
            }
            Write-Host '  Restored TCP and Windows power-plan settings.' -ForegroundColor Green
        }
        catch {
            $errors += ("Network settings: {0}" -f $_.Exception.Message)
            Write-Host ("  NETWORK RESTORE FAILED: {0}" -f $_.Exception.Message) -ForegroundColor Red
        }
    }

    if ($errors.Count -gt 0) {
        throw ("Rollback was incomplete:`n" + ($errors -join "`n"))
    }
    Write-Host 'Rollback completed. Sign out or restart Windows if a setting does not revert immediately.' -ForegroundColor Green
    exit 0
}

# ------------------------- POST-REBOOT VERIFICATION --------------------------
if ($Verify) {
    Write-Section 'POST-REBOOT REGISTRY VERIFICATION'
    $backup = Get-LatestBackup
    if ($null -eq $backup) {
        throw "No saved profile was found. Apply the profile first. Backup folder: $BackupRoot"
    }

    $planFile = Join-Path $backup.FullName 'ChangePlan.json'
    $stateFile = Join-Path $backup.FullName 'RegistryState.json'
    $skipFile = Join-Path $backup.FullName 'SkippedSettings.json'
    if (-not (Test-Path -LiteralPath $planFile) -or -not (Test-Path -LiteralPath $stateFile)) {
        throw "The latest backup does not contain verification data: $($backup.FullName)"
    }

    $verifyPlan = @(Get-Content -LiteralPath $planFile -Raw | ConvertFrom-Json)
    $verifyBaseline = @(Get-Content -LiteralPath $stateFile -Raw | ConvertFrom-Json)
    $verifySkipped = @()
    if (Test-Path -LiteralPath $skipFile) {
        $verifySkipped = @(Get-Content -LiteralPath $skipFile -Raw | ConvertFrom-Json)
    }

    $baselineMap = @{}
    foreach ($baselineItem in $verifyBaseline) {
        $baselineMap["$($baselineItem.Path)|$($baselineItem.Name)"] = $baselineItem
    }
    $skipMap = @{}
    foreach ($skipItem in $verifySkipped) {
        $skipMap["$($skipItem.Path)|$($skipItem.Name)"] = $skipItem
    }

    Write-Status 'Backup set' $backup.Name
    Write-Status 'Settings checked' $verifyPlan.Count
    Write-Host ''
    $verifiedCount = 0
    $changedCount = 0
    $alreadyCount = 0
    $failedCount = 0
    $skippedCount = 0

    for ($i = 0; $i -lt $verifyPlan.Count; $i++) {
        $item = $verifyPlan[$i]
        $keyId = "$($item.Path)|$($item.Name)"
        $percent = [int](($i + 1) * 100 / [math]::Max(1, $verifyPlan.Count))
        Write-Progress -Activity 'Verifying registry tweaks after reboot' `
            -Status ("Checking {0}/{1}" -f ($i + 1), $verifyPlan.Count) `
            -PercentComplete $percent

        $actualValue = $null
        $actualKind = $null
        $found = $false
        try {
            if (Test-Path -LiteralPath $item.Path) {
                $key = Get-Item -LiteralPath $item.Path -ErrorAction Stop
                if ($key.GetValueNames() -contains [string]$item.Name) {
                    $found = $true
                    $actualKind = $key.GetValueKind([string]$item.Name).ToString()
                    $actualValue = $key.GetValue(
                        [string]$item.Name,
                        $null,
                        [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames
                    )
                }
            }
        }
        catch {
            $found = $false
        }

        $expectedText = [string]$item.Value
        $actualText = if ($found) { [string]$actualValue } else { '<not present>' }
        $kindMatches = $found -and ($actualKind -eq [string]$item.Kind)
        $valueMatches = $found -and ($actualText -ceq $expectedText)

        if ($valueMatches -and $kindMatches) {
            $verifiedCount++
            $baselineItem = $baselineMap[$keyId]
            $wasAlreadySet = $false
            if ($null -ne $baselineItem -and $baselineItem.Existed) {
                $wasAlreadySet = ([string]$baselineItem.Kind -eq [string]$item.Kind) -and
                                 ([string]$baselineItem.Value -ceq $expectedText)
            }

            if ($wasAlreadySet) {
                $alreadyCount++
                $status = 'ALREADY MATCHED'
                $statusColor = 'DarkGreen'
            }
            else {
                $changedCount++
                $status = 'CHANGED + VERIFIED'
                $statusColor = 'Green'
            }

            if ($status -eq 'CHANGED + VERIFIED') {
                Write-Host ("  [CONFIRMED] {0}" -f $item.Name) -ForegroundColor Green
                $beforeText = if ($null -ne $baselineItem -and $baselineItem.Existed) { Format-Value $baselineItem.Value } else { '<not present>' }
                Write-Host ("       {0}  ->  {1}" -f $beforeText, $actualText) -ForegroundColor Gray
            }
            elseif ($DetailedOutput) {
                Write-Host ("  [ALREADY OK] {0}" -f $item.Name) -ForegroundColor DarkGray
            }
            if ($DetailedOutput) {
                Write-Host ("       Path  : {0}" -f $item.Path) -ForegroundColor DarkGray
            }
        }
        elseif ($skipMap.ContainsKey($keyId)) {
            $skippedCount++
            Write-Host ("  [SKIPPED] {0} - access was denied during apply" -f $item.Name) -ForegroundColor Yellow
            if ($DetailedOutput) {
                Write-Host ("       Current: {0}" -f $actualText) -ForegroundColor DarkGray
            }
        }
        else {
            $failedCount++
            Write-Host ("  [NOT APPLIED] {0} | expected {1}, found {2}" -f $item.Name, $expectedText, $actualText) -ForegroundColor Red
            if ($DetailedOutput) {
                Write-Host ("       Expected type: {0}; actual type: {1}" -f $item.Kind, $actualKind) -ForegroundColor DarkGray
                Write-Host ("       Path: {0}" -f $item.Path) -ForegroundColor DarkGray
            }
        }
    }
    Write-Progress -Activity 'Verifying registry tweaks after reboot' -Completed

    Write-Section 'NETWORK CHECK'
    $tcpNow = Get-TcpGlobalState
    if ($null -ne $tcpNow) {
        Write-Status 'TCP Receive-Side Scaling' $tcpNow.RSS $(if ($tcpNow.RSS -eq 'enabled') { 'Green' } else { 'Yellow' })
        Write-Status 'TCP auto-tuning' $tcpNow.AutoTuning $(if ($tcpNow.AutoTuning -eq 'normal') { 'Green' } else { 'Yellow' })
    }
    else {
        Write-Status 'TCP global settings' 'Could not read' Yellow
    }
    Write-Section 'POWER PLAN CHECK'
    try {
        $powerNow = Get-PowerCfgState
        Write-Status 'Processor boost mode (AC)' $powerNow.AcBoostMode $(if ($powerNow.AcBoostMode -eq 2) { 'Green' } else { 'Yellow' })
        Write-Status 'Processor boost mode (DC)' $powerNow.DcBoostMode $(if ($powerNow.DcBoostMode -eq 2) { 'Green' } else { 'Yellow' })
        foreach ($alias in @('CPMINCORES','CPMAXCORES','PERFBOOSTMODE')) {
            $attr = @($powerNow.Attributes | Where-Object { $_.Alias -eq $alias }) | Select-Object -First 1
            if ($null -eq $attr) {
                Write-Status ("Power setting visibility: " + $alias) 'Not available' Yellow
            }
            else {
                Write-Status ($alias + ' hidden') ([string]$attr.Hidden) $(if ($attr.Hidden) { 'Green' } else { 'Yellow' })
            }
        }
    }
    catch {
        Write-Status 'Power plan check' $_.Exception.Message Yellow
    }

    Write-Section 'VERIFICATION RESULTS'
    Write-Status 'Verified successfully' $verifiedCount Green
    Write-Status 'Values changed' $changedCount Green
    Write-Status 'Already matched' $alreadyCount Cyan
    Write-Status 'Skipped at apply' $skippedCount Yellow
    Write-Status 'Not applied / mismatch' $failedCount $(if ($failedCount -gt 0) { 'Red' } else { 'Green' })

    if ($failedCount -eq 0) {
        Write-Host ''
        Write-Host '  [SUCCESS] All non-skipped registry tweaks match their configured values.' -ForegroundColor Green
    }
    else {
        Write-Host ''
        Write-Host '  [WARNING] Some registry tweaks do not match. Review the entries marked NOT APPLIED.' -ForegroundColor Yellow
    }

    Write-Host ''
    Write-Host '  Verification checks registry values; it does not measure FPS or prove a performance gain.' -ForegroundColor DarkGray
    exit $(if ($failedCount -gt 0) { 2 } else { 0 })
}

# ---------------------- PRIMARY NETWORK ADAPTER ------------------------------
$tcpInterfacePath = $null
try {
    $defaultRoute = Get-NetRoute -AddressFamily IPv4 -DestinationPrefix '0.0.0.0/0' -ErrorAction Stop |
        Where-Object { $_.State -eq 'Alive' } |
        Sort-Object RouteMetric, InterfaceMetric |
        Select-Object -First 1

    if ($null -ne $defaultRoute) {
        $primaryAdapter = Get-NetAdapter -ErrorAction Stop |
            Where-Object { $_.ifIndex -eq $defaultRoute.InterfaceIndex } |
            Select-Object -First 1

        if ($null -ne $primaryAdapter -and $primaryAdapter.Status -eq 'Up' -and $primaryAdapter.InterfaceGuid) {
            $adapterGuid = ([guid]$primaryAdapter.InterfaceGuid).ToString('B')
            $tcpInterfacePath = "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\$adapterGuid"
            if ($DetailedOutput) {
                Write-Host ("  Network adapter detected: {0}" -f $primaryAdapter.Name) -ForegroundColor DarkGray
            }
        }
    }
}
catch {
    if ($DetailedOutput) {
        Write-Warning ("Could not identify the active IPv4 adapter; TCP-specific tweaks will be omitted. {0}" -f $_.Exception.Message)
    }
}

# ----------------------------- REGISTRY PLAN --------------------------------
$Changes = @(
    # Performance / power throttling
    @{ Category='Performance'; Path='HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling'; Name='PowerThrottlingOff'; Kind='DWord'; Value=1; Note='Disables Windows Power Throttling for supported processes. Can increase CPU activity, heat, fan noise and power use.' },

    # Gaming and capture
    @{ Category='Gaming'; Path='HKCU:\System\GameConfigStore'; Name='GameDVR_Enabled'; Kind='DWord'; Value=0; Note='Disables background Game DVR capture for the current user.' },
    @{ Category='Gaming'; Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR'; Name='AppCaptureEnabled'; Kind='DWord'; Value=0; Note='Disables app/game capture for the current user.' },
    @{ Category='Gaming'; Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR'; Name='AllowGameDVR'; Kind='DWord'; Value=0; Note='Disables Game DVR through policy where supported.' },
    @{ Category='Gaming'; Path='HKCU:\Software\Microsoft\GameBar'; Name='ShowStartupPanel'; Kind='DWord'; Value=0; Note='Suppresses the Game Bar first-run panel.' },
    @{ Category='Gaming'; Path='HKCU:\Software\Microsoft\GameBar'; Name='UseNexusForGameBarEnabled'; Kind='DWord'; Value=0; Note='Disables the Game Bar overlay entry point. Re-enable if you use the overlay.' },
    @{ Category='Gaming'; Path='HKCU:\Software\Microsoft\GameBar'; Name='AutoGameModeEnabled'; Kind='DWord'; Value=1; Note='Enables automatic Windows Game Mode where supported.' },

    # Privacy and background suggestions
    @{ Category='Background content'; Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo'; Name='Enabled'; Kind='DWord'; Value=0; Note='Disables the advertising ID for this user.' },
    @{ Category='Background content'; Path='HKCU:\SOFTWARE\Policies\Microsoft\Windows\CloudContent'; Name='DisableTailoredExperiencesWithDiagnosticData'; Kind='DWord'; Value=1; Note='Disables tailored experiences based on diagnostic data where supported.' },
    @{ Category='Background content'; Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent'; Name='DisableWindowsConsumerFeatures'; Kind='DWord'; Value=1; Note='Suppresses certain consumer suggestions on editions that enforce this policy.' },
    @{ Category='Background content'; Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent'; Name='DisableSoftLanding'; Kind='DWord'; Value=1; Note='Suppresses Windows tips and soft-landing suggestions where supported.' },
    @{ Category='Background content'; Path='HKCU:\SOFTWARE\Policies\Microsoft\Windows\CloudContent'; Name='DisableWindowsSpotlightFeatures'; Kind='DWord'; Value=1; Note='Disables selected Spotlight features for this user where supported.' },
    @{ Category='Background content'; Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent'; Name='DisableCloudOptimizedContent'; Kind='DWord'; Value=1; Note='Suppresses cloud-optimized consumer content where supported; may reduce some Windows suggestions.' },
    @{ Category='Background content'; Path='HKCU:\SOFTWARE\Policies\Microsoft\Windows\CloudContent'; Name='DisableWindowsSpotlightOnActionCenter'; Kind='DWord'; Value=1; Note='Suppresses Spotlight suggestions in Action Center where supported.' },
    @{ Category='Background content'; Path='HKCU:\SOFTWARE\Policies\Microsoft\Windows\CloudContent'; Name='DisableWindowsSpotlightOnSettings'; Kind='DWord'; Value=1; Note='Suppresses suggested content in Settings where supported.' },
    @{ Category='Background content'; Path='HKCU:\SOFTWARE\Policies\Microsoft\Windows\CloudContent'; Name='DisableWindowsSpotlightWindowsWelcomeExperience'; Kind='DWord'; Value=1; Note='Suppresses Windows Welcome Experience promotions where supported.' },
    @{ Category='Background content'; Path='HKCU:\SOFTWARE\Policies\Microsoft\Windows\CloudContent'; Name='DisableSpotlightCollectionOnDesktop'; Kind='DWord'; Value=1; Note='Disables Spotlight collection on the desktop where supported.' },

    # Telemetry and diagnostic-data minimisation
    @{ Category='Telemetry and diagnostics'; Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection'; Name='AllowTelemetry'; Kind='DWord'; Value=1; Note='Sets Windows 11 Pro to Required diagnostic data, the lowest supported level on Pro. Security-only value 0 is not supported on Pro.' },
    @{ Category='Telemetry and diagnostics'; Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection'; Name='DisableTelemetryOptInSettingsUx'; Kind='DWord'; Value=1; Note='Disables the diagnostic-data opt-in controls in Settings so the policy level is not raised through the UI.' },
    @{ Category='Telemetry and diagnostics'; Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection'; Name='LimitDiagnosticLogCollection'; Kind='DWord'; Value=1; Note='Prevents collection of additional diagnostic logs.' },
    @{ Category='Telemetry and diagnostics'; Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection'; Name='LimitDumpCollection'; Kind='DWord'; Value=1; Note='Limits eligible diagnostic dumps to kernel mini dumps and user-mode triage dumps.' },
    @{ Category='Telemetry and diagnostics'; Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection'; Name='DoNotShowFeedbackNotifications'; Kind='DWord'; Value=1; Note='Stops Windows feedback-request notifications; this is separate from diagnostic telemetry.' },
    @{ Category='Telemetry and diagnostics'; Path='HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows'; Name='CEIPEnable'; Kind='DWord'; Value=0; Note='Opts this PC out of the Windows Customer Experience Improvement Program.' },
    @{ Category='Telemetry and diagnostics'; Path='HKCU:\Software\Microsoft\Siuf\Rules'; Name='PeriodInNanoSeconds'; Kind='QWord'; Value=0; Note='Sets Windows user feedback request frequency to Never.' },
    @{ Category='Telemetry and diagnostics'; Path='HKCU:\Software\Microsoft\Siuf\Rules'; Name='NumberOfSIUFInPeriod'; Kind='DWord'; Value=0; Note='Sets Windows user feedback request frequency to Never.' },

    # Storage and download cache policies
    @{ Category='Storage maintenance'; Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\StorageSense'; Name='AllowStorageSenseGlobal'; Kind='DWord'; Value=1; Note='Allows Storage Sense to run where supported.' },
    @{ Category='Storage maintenance'; Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\StorageSense'; Name='AllowStorageSenseTemporaryFilesCleanup'; Kind='DWord'; Value=1; Note='Allows Storage Sense to clean eligible temporary files; user files are not targeted by this setting.' },
    @{ Category='Storage maintenance'; Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\StorageSense'; Name='ConfigStorageSenseGlobalCadence'; Kind='DWord'; Value=0; Note='Uses the low-disk-space cadence rather than a daily cleanup schedule.' },
    @{ Category='Delivery Optimization'; Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization'; Name='DODownloadMode'; Kind='DWord'; Value=0; Note='Uses Microsoft download sources instead of peer-to-peer sharing.' },
    @{ Category='Delivery Optimization'; Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization'; Name='DOMaxCacheAge'; Kind='DWord'; Value=86400; Note='Limits Delivery Optimization cache age to one day.' },
    @{ Category='Delivery Optimization'; Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization'; Name='DOAbsoluteMaxCacheSize'; Kind='DWord'; Value=5; Note='Caps the Delivery Optimization cache at 5 GB.' },
    @{ Category='Delivery Optimization'; Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization'; Name='DOPercentageMaxBackgroundBandwidth'; Kind='DWord'; Value=25; Note='Limits background Delivery Optimization downloads to 25 percent of available bandwidth.' },

    # Explorer and Start responsiveness (restored from the 33-tweak profile)
    @{ Category='Explorer and Start responsiveness'; Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize'; Name='StartupDelayInMSec'; Kind='DWord'; Value=0; Note='Removes the legacy Explorer startup delay where applicable.' },
    @{ Category='Explorer and Start responsiveness'; Path='HKCU:\Control Panel\Desktop'; Name='MenuShowDelay'; Kind='String'; Value='100'; Note='Reduces menu response delay; does not disable Windows animations.' },
    @{ Category='Explorer and Start responsiveness'; Path='HKCU:\Control Panel\Desktop'; Name='AutoEndTasks'; Kind='String'; Value='0'; Note='Does not force-close applications automatically at sign-out.' },
    @{ Category='Explorer and Start responsiveness'; Path='HKCU:\Control Panel\Desktop'; Name='HungAppTimeout'; Kind='String'; Value='3000'; Note='Sets the application-hang wait threshold to 3 seconds; can make hung-app prompts appear sooner.' },
    @{ Category='Explorer and Start responsiveness'; Path='HKCU:\Control Panel\Desktop'; Name='WaitToKillAppTimeout'; Kind='String'; Value='3000'; Note='Sets the application shutdown wait threshold to 3 seconds; unsaved work may still require attention.' },
    @{ Category='Explorer and Start responsiveness'; Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; Name='SeparateProcess'; Kind='DWord'; Value=1; Note='Runs folder windows in separate Explorer processes; increases memory use and may improve isolation, not raw speed.' },
    @{ Category='Explorer and Start responsiveness'; Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; Name='LaunchTo'; Kind='DWord'; Value=1; Note='Opens File Explorer to This PC.' },
    @{ Category='Explorer and Start responsiveness'; Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; Name='Start_TrackDocs'; Kind='DWord'; Value=0; Note='Stops Start menu recent-document tracking.' },
    @{ Category='Explorer and Start responsiveness'; Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; Name='Start_TrackProgs'; Kind='DWord'; Value=0; Note='Stops Start menu app-launch tracking.' },
    @{ Category='Explorer and Start responsiveness'; Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; Name='HideFileExt'; Kind='DWord'; Value=0; Note='Shows known file extensions in File Explorer; improves file-type visibility, not CPU speed.' },
    @{ Category='Explorer and Start responsiveness'; Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; Name='Hidden'; Kind='DWord'; Value=1; Note='Shows hidden files; protected operating-system files remain hidden.' },
    @{ Category='Explorer and Start responsiveness'; Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; Name='ShowSuperHidden'; Kind='DWord'; Value=0; Note='Keeps protected operating-system files hidden.' },
    @{ Category='Explorer and Start responsiveness'; Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; Name='ShowStatusBar'; Kind='DWord'; Value=1; Note='Shows the File Explorer status bar.' },
    @{ Category='Explorer and Start responsiveness'; Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; Name='ShowSyncProviderNotifications'; Kind='DWord'; Value=0; Note='Hides promotional notifications from sync providers in File Explorer.' },
    @{ Category='Explorer and Start responsiveness'; Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer'; Name='ShowRecent'; Kind='DWord'; Value=0; Note='Hides recent files in Quick Access/Home where supported.' },
    @{ Category='Explorer and Start responsiveness'; Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer'; Name='ShowFrequent'; Kind='DWord'; Value=0; Note='Hides frequently used folders in Quick Access/Home where supported.' },
    @{ Category='Explorer and Start responsiveness'; Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; Name='Start_IrisRecommendations'; Kind='DWord'; Value=0; Note='Turns off Start menu recommendations where supported.' },
    @{ Category='Explorer and Start responsiveness'; Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; Name='TaskbarDa'; Kind='DWord'; Value=0; Note='Hides the Widgets taskbar button; this is a UI preference, not a direct performance boost.' },
    @{ Category='Explorer and Start responsiveness'; Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; Name='Start_Layout'; Kind='DWord'; Value=1; Note='Uses the Start layout with more pinned items where supported.' },
    @{ Category='Explorer and Start responsiveness'; Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Start'; Name='ShowAllPinsList'; Kind='DWord'; Value=1; Note='Shows the all-pins list by default where supported.' },

    # Additional MMCSS Games task values
    @{ Category='Experimental gaming scheduler'; Path='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games'; Name='Affinity'; Kind='DWord'; Value=0; Note='Leaves processor affinity under Windows control.' },
    @{ Category='Experimental gaming scheduler'; Path='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games'; Name='Background Only'; Kind='String'; Value='False'; Note='Marks the Games task as foreground-capable.' },

    # CPU and memory-manager values from the 33-tweak profile
    @{ Category='CPU and memory'; Path='HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management'; Name='DisablePagingExecutive'; Kind='DWord'; Value=0; Note='Keeps pageable kernel components pageable; avoids forcing them into RAM.' },
    @{ Category='CPU and memory'; Path='HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management'; Name='LargeSystemCache'; Kind='DWord'; Value=0; Note='Retains workstation cache behaviour rather than server-style caching.' },
    @{ Category='CPU and memory'; Path='HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management'; Name='ClearPageFileAtShutdown'; Kind='DWord'; Value=0; Note='Avoids clearing the pagefile at shutdown; improves shutdown time in some configurations.' },

    # GPU timeout detection and recovery (experimental; can prolong a real GPU hang)
    @{ Category='Experimental GPU TDR'; Path='HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers'; Name='TdrDelay'; Kind='DWord'; Value=10; Note='Allows more time before Windows starts GPU timeout recovery; may make a frozen GPU appear unresponsive for longer.' },
    @{ Category='Experimental GPU TDR'; Path='HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers'; Name='TdrDdiDelay'; Kind='DWord'; Value=20; Note='Allows additional time for a driver thread to leave; may prolong recovery from a driver hang.' },

    # Shutdown responsiveness (shorter waits; does not force-close user apps)
    @{ Category='Shutdown responsiveness'; Path='HKLM:\SYSTEM\CurrentControlSet\Control'; Name='WaitToKillServiceTimeout'; Kind='String'; Value='5000'; Note='Sets the service shutdown wait threshold to 5 seconds; a service that needs longer may not stop cleanly.' },

    # File system
    @{ Category='File system'; Path='HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem'; Name='NtfsDisableLastAccessUpdate'; Kind='DWord'; Value=1; Note='Disables NTFS last-access timestamp updates; benefit is workload-dependent.' }
)

# Aggressive MMCSS and foreground scheduling values are included by default.
$Changes += @(
    @{ Category='Experimental gaming scheduler'; Path='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile'; Name='SystemResponsiveness'; Kind='DWord'; Value=10; Note='Experimental MMCSS responsiveness reservation; may change resources available to background multimedia/network tasks.' },
    @{ Category='Experimental gaming scheduler'; Path='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile'; Name='NetworkThrottlingIndex'; Kind='DWord'; Value=-1; Note='Experimental MMCSS network-throttling override (DWORD 0xFFFFFFFF); not a guaranteed latency improvement.' },
    @{ Category='Experimental gaming scheduler'; Path='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games'; Name='Priority'; Kind='DWord'; Value=6; Note='Experimental Games MMCSS task priority; Windows/game versions may ignore or override it.' },
    @{ Category='Experimental gaming scheduler'; Path='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games'; Name='Scheduling Category'; Kind='String'; Value='High'; Note='Experimental Games MMCSS scheduling category; can reduce resources available to background tasks.' },
    @{ Category='Experimental gaming scheduler'; Path='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games'; Name='SFIO Priority'; Kind='String'; Value='High'; Note='Experimental Games task storage I/O priority; impact depends on Windows build and workload.' },
    @{ Category='Experimental CPU scheduling'; Path='HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl'; Name='Win32PrioritySeparation'; Kind='DWord'; Value=38; Note='Experimental foreground scheduling value (0x26); may perform worse than Windows defaults.' }
)

# TCP latency-related registry tweaks are applied only to the active IPv4 default-route adapter.
if ($null -ne $tcpInterfacePath) {
    $Changes += @(
        @{ Category='Experimental TCP'; Path=$tcpInterfacePath; Name='TcpAckFrequency'; Kind='DWord'; Value=1; Note='Experimental TCP acknowledgement behaviour for the active adapter; can increase packet overhead.' },
        @{ Category='Experimental TCP'; Path=$tcpInterfacePath; Name='TCPNoDelay'; Kind='DWord'; Value=1; Note='Disables Nagle buffering for applicable TCP traffic; does not affect UDP and may increase packet count.' },
        @{ Category='Experimental TCP'; Path=$tcpInterfacePath; Name='TcpDelAckTicks'; Kind='DWord'; Value=0; Note='Experimental delayed-ACK timer for the active adapter; may be ignored by some Windows versions.' }
    )
}

# Explicit opt-outs are available; by default the full aggressive set is included.
if ($SkipTdrAndTcp) {
    $Changes = @($Changes | Where-Object { $_.Category -notin @('Experimental GPU TDR','Experimental TCP') })
}
if ($SkipExperimentalScheduler) {
    $Changes = @($Changes | Where-Object { $_.Category -ne 'Experimental gaming scheduler' -and $_.Category -ne 'Experimental CPU scheduling' })
}

# Validate the plan before touching the registry.
$duplicates = @($Changes | Group-Object { "$($_.Path)|$($_.Name)" } | Where-Object { $_.Count -gt 1 })
if ($duplicates.Count -gt 0) { throw 'Duplicate registry value definitions detected. No changes were made.' }
if ($Changes.Count -lt 1) { throw 'The registry plan is empty.' }

Write-Section 'PROFILE SUMMARY'
Write-Status 'Registry settings' $Changes.Count Green
Write-Status 'Tweak groups' (@($Changes | ForEach-Object { $_['Category'] } | Where-Object { $_ } | Sort-Object -Unique).Count)
Write-Status 'GPU TDR / TCP tweaks' $(if ($SkipTdrAndTcp) { 'Excluded' } else { 'Included when adapter detected' }) Yellow
Write-Status 'Gaming scheduler' $(if ($SkipExperimentalScheduler) { 'Excluded' } else { 'Included' }) Yellow
Write-Status 'Visual effects' 'Unchanged' Green
Write-Status 'Display and sleep' 'Unchanged' Green
Write-Status 'Network profile' 'TCP throughput settings' Cyan
Write-Status 'Telemetry profile' 'Required data only; CEIP, feedback and extra logs limited' Green

# Capture all original values before displaying or applying.
$Snapshots = @()
for ($i = 0; $i -lt $Changes.Count; $i++) {
    $percent = [int](($i + 1) * 100 / $Changes.Count)
    Write-Progress -Activity 'Preparing registry backup' `
        -Status ("Reading original settings  {0}/{1}" -f ($i + 1), $Changes.Count) `
        -PercentComplete $percent
    $Snapshots += Get-RegistrySnapshot -Path $Changes[$i].Path -Name $Changes[$i].Name
}
Write-Progress -Activity 'Preparing registry backup' -Completed

if ($PreviewOnly -or $DetailedOutput) {
    Write-Section 'REGISTRY CHANGE PLAN'
    for ($i = 0; $i -lt $Changes.Count; $i++) {
        $change = $Changes[$i]
        $before = $Snapshots[$i]
        $oldValue = if ($before.Existed) { Format-Value $before.Value } else { '<not present>' }

        if ($DetailedOutput) { Write-Host ("  [{0:D2}/{1:D2}] {2}" -f ($i + 1), $Changes.Count, $change.Name) -ForegroundColor Cyan }
        if ($DetailedOutput) {
            Write-Host ("       Group   : {0}" -f $change.Category) -ForegroundColor DarkCyan
            Write-Host ("       Current : {0}" -f $oldValue) -ForegroundColor Yellow
            Write-Host ("       New     : {0} ({1})" -f (Format-Value $change.Value), $change.Kind) -ForegroundColor Green
            Write-Host ("       Path    : {0}" -f $change.Path) -ForegroundColor DarkGray
            Write-Host ("       Purpose : {0}" -f $change.Note) -ForegroundColor Gray
        }
    }
}
else {
    Write-Section 'READY TO APPLY'
    Write-Host ("  {0} registry settings are selected." -f $Changes.Count) -ForegroundColor White
    Write-Host '  Your current settings will be backed up before any changes.' -ForegroundColor DarkGray
}

if ($PreviewOnly) {
    Write-Section 'PREVIEW COMPLETE'
    Write-Section 'ADDITIONAL POWER PLAN OPERATIONS'
    Write-Host '  AC processor boost mode  : index 2' -ForegroundColor Green
    Write-Host '  DC processor boost mode  : index 2' -ForegroundColor Green
    Write-Host '  Hide CPMINCORES           : Yes' -ForegroundColor Green
    Write-Host '  Hide CPMAXCORES           : Yes' -ForegroundColor Green
    Write-Host '  Hide PERFBOOSTMODE        : Yes' -ForegroundColor Green
    Write-Host '  Windows Power Throttling registry value: PowerThrottlingOff = 1' -ForegroundColor Green
    Write-Host '  Windows telemetry policy: AllowTelemetry = 1 (Required; Windows 11 Pro minimum)' -ForegroundColor Green
    Write-Host '  Diagnostic logs, dump collection, CEIP and feedback prompts are restricted.' -ForegroundColor Green
    Write-Host '  Intel thermal throttling / PL1-PL2 / PROCHOT: unchanged' -ForegroundColor Yellow
    Write-Host '  Preview finished. No settings were changed.' -ForegroundColor Green
    exit 0
}

if (-not $Force) {
    Write-Section 'BEFORE YOU CONTINUE'
    Write-Host '  This profile includes experimental GPU, network and scheduler tweaks.' -ForegroundColor Yellow
    Write-Host '  Windows Power Throttling is disabled; Intel thermal and electrical safeguards remain enabled.' -ForegroundColor Yellow
    Write-Host '  Windows 11 Pro still sends Required diagnostic data; Security-only telemetry level is Enterprise/Education/Server only.' -ForegroundColor Yellow
    Write-Host '  Telemetry policies reduce collection; they do not block every Windows or Microsoft service connection.' -ForegroundColor Yellow
    Write-Host '  Processor boost mode is set to index 2, which can increase heat and battery use.' -ForegroundColor Yellow
    Write-Host '  They are not guaranteed to improve FPS or latency.' -ForegroundColor Yellow
    Write-Host '  Disabling Power Throttling may increase heat, fan noise and power use.' -ForegroundColor Yellow
    Write-Host '  Shorter shutdown waits may leave slow apps or services less time to close.' -ForegroundColor Yellow
    Write-Host '  Wi-Fi adapter power setting is not modified; this NetAdapter cmdlet does not expose that control.' -ForegroundColor Yellow
    Write-Host '  TCP RSS and auto-tuning use Windows-supported settings; they do not increase your ISP plan speed.' -ForegroundColor Yellow
    Write-Host ''
    $answer = Read-Host "  Type APPLY to back up and apply $($Changes.Count) settings"
    if ($answer -cne 'APPLY') {
        Write-Host 'Cancelled. No registry changes were made.' -ForegroundColor Yellow
        exit 0
    }
}

# Reuse and extend the original baseline when a previous version of this profile
# exists. Existing snapshots are preserved; only newly introduced registry values
# are appended using their current pre-apply state.
$existingBackup = Get-LatestBackup
$reuseBackup = $false
if ($null -ne $existingBackup) {
    $metadataPath = Join-Path $existingBackup.FullName 'Metadata.json'
    $networkPath = Join-Path $existingBackup.FullName 'NetworkState.json'
    $planPath = Join-Path $existingBackup.FullName 'ChangePlan.json'
    $registryStatePath = Join-Path $existingBackup.FullName 'RegistryState.json'
    try {
        $existingMetadata = Get-Content -LiteralPath $metadataPath -Raw | ConvertFrom-Json
        $existingState = @(Get-Content -LiteralPath $registryStatePath -Raw | ConvertFrom-Json)

        if ($existingState.Count -le $Snapshots.Count -and
            (Test-Path -LiteralPath $networkPath) -and
            (Test-Path -LiteralPath $planPath)) {

            $BackupDir = $existingBackup.FullName
            $existingKeys = @{}
            foreach ($savedItem in $existingState) {
                $existingKeys["$($savedItem.Path)|$($savedItem.Name)"] = $true
            }

            $newBaselineItems = @()
            foreach ($currentSnapshot in $Snapshots) {
                $snapshotKey = "$($currentSnapshot.Path)|$($currentSnapshot.Name)"
                if (-not $existingKeys.ContainsKey($snapshotKey)) {
                    $newBaselineItems += $currentSnapshot
                }
            }

            $mergedState = @($existingState) + @($newBaselineItems)
            $mergedState | ConvertTo-Json -Depth 8 |
                Set-Content -LiteralPath $registryStatePath -Encoding UTF8

            # Keep the original CPU boost/TCP baseline. Refresh only the exact
            # visibility DWORDs because the previous version failed before hiding them.
            $savedNetworkForRefresh = Get-Content -LiteralPath $networkPath -Raw | ConvertFrom-Json
            $currentPowerForRefresh = Get-PowerCfgState
            if ($null -ne $savedNetworkForRefresh.PowerCfg) {
                $savedNetworkForRefresh.PowerCfg.Attributes = @($currentPowerForRefresh.Attributes)
                $savedNetworkForRefresh | ConvertTo-Json -Depth 8 |
                    Set-Content -LiteralPath $networkPath -Encoding UTF8
            }

            $Changes | ConvertTo-Json -Depth 8 |
                Set-Content -LiteralPath $planPath -Encoding UTF8

            $existingMetadata.RegistryCount = $Snapshots.Count
            $existingMetadata.TelemetryProfile = 'Required diagnostic data; CEIP and feedback opt-outs; diagnostic logs and dumps limited'
            $existingMetadata.WindowsProTelemetryLevel = 1
            $existingMetadata | ConvertTo-Json -Depth 8 |
                Set-Content -LiteralPath $metadataPath -Encoding UTF8

            $reuseBackup = $true
            Write-Status 'Original backup extended' ("{0} original snapshots + {1} new snapshots" -f $existingState.Count, $newBaselineItems.Count) Green
        }
    }
    catch {
        $reuseBackup = $false
    }
}

if (-not $reuseBackup) {
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $BackupDir = Join-Path $BackupRoot "$ProfileName-$stamp"
    New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null
    $ProfileName | Set-Content -LiteralPath (Join-Path $BackupDir 'ProfileName.txt') -Encoding ASCII
    $Snapshots | ConvertTo-Json -Depth 8 |
        Set-Content -LiteralPath (Join-Path $BackupDir 'RegistryState.json') -Encoding UTF8

    $networkBaseline = [pscustomobject]@{
        TcpGlobal = Get-TcpGlobalState
        PowerCfg = Get-PowerCfgState
    }
    $networkBaseline | ConvertTo-Json -Depth 8 |
        Set-Content -LiteralPath (Join-Path $BackupDir 'NetworkState.json') -Encoding UTF8

    $Changes | ConvertTo-Json -Depth 8 |
        Set-Content -LiteralPath (Join-Path $BackupDir 'ChangePlan.json') -Encoding UTF8

    [pscustomobject]@{
        ProfileName = $ProfileName
        Created = (Get-Date).ToString('o')
        Computer = $env:COMPUTERNAME
        User = [Security.Principal.WindowsIdentity]::GetCurrent().Name
        OperatingSystem = $os.Caption
        Build = $os.BuildNumber
        RegistryCount = $Snapshots.Count
        ProcessorBoostModeAC = 2
        ProcessorBoostModeDC = 2
        PowerPlanSettingsHidden = @('CPMINCORES','CPMAXCORES','PERFBOOSTMODE')
        WindowsPowerThrottlingDisabled = $true
        TelemetryProfile = 'Required diagnostic data; CEIP and feedback opt-outs; diagnostic logs and dumps limited'
        WindowsProTelemetryLevel = 1
        SkipTdrAndTcp = [bool]$SkipTdrAndTcp
        SkipExperimentalScheduler = [bool]$SkipExperimentalScheduler
    } | ConvertTo-Json -Depth 8 |
        Set-Content -LiteralPath (Join-Path $BackupDir 'Metadata.json') -Encoding UTF8

    Write-Status 'Backup created' $BackupDir Green
}

# Apply. Access-denied values are skipped; other errors cause full rollback.
$applied = 0
$skipped = @()
$appliedSnapshots = @()

try {
    Write-Section 'APPLYING OPTIMIZATIONS'
    for ($i = 0; $i -lt $Changes.Count; $i++) {
        $change = $Changes[$i]
        $snapshot = $Snapshots[$i]
        $percent = [int](($i + 1) * 100 / $Changes.Count)
        Write-Progress -Activity 'Applying registry performance profile' `
            -Status ("{0}/{1}  |  {2}" -f ($i + 1), $Changes.Count, $change.Category) `
            -PercentComplete $percent

        try {
            Set-RegistryValue -Change $change
            $applied++
            $appliedSnapshots += $snapshot
            if ($DetailedOutput) {
                Write-Host ("  APPLIED  {0}" -f $change.Name) -ForegroundColor Green
            }
        }
        catch {
            $message = [string]$_.Exception.Message
            $isDenied = ($_.Exception -is [System.UnauthorizedAccessException]) -or
                        ($_.Exception -is [System.Security.SecurityException]) -or
                        ($message -match '(?i)access is denied|unauthorized|requested registry access is not allowed')

            if (-not $isDenied) { throw }

            # Registry writes are atomic; a denied write leaves the original value unchanged.
            $skipped += [pscustomobject]@{ Name=$change.Name; Path=$change.Path; Reason=$message }
            if ($DetailedOutput) {
                Write-Host ("  SKIPPED (access denied)  {0}" -f $change.Name) -ForegroundColor Yellow
            }
        }
    }
    Write-Progress -Activity 'Applying registry performance profile' -Completed
}
catch {
    Write-Progress -Activity 'Applying registry performance profile' -Completed
    $failure = $_
    Write-Section 'RECOVERING ORIGINAL SETTINGS'
    $rollbackErrors = @()
    [array]::Reverse($appliedSnapshots)
    for ($r = 0; $r -lt $appliedSnapshots.Count; $r++) {
        $snapshot = $appliedSnapshots[$r]
        $percent = [int](($r + 1) * 100 / [math]::Max(1, $appliedSnapshots.Count))
        Write-Progress -Activity 'Automatic recovery' `
            -Status ("Restoring {0}/{1}" -f ($r + 1), $appliedSnapshots.Count) `
            -PercentComplete $percent
        try {
            Restore-RegistrySnapshot -Snapshot $snapshot
            if ($DetailedOutput) {
                Write-Host ("  RESTORED  {0}" -f $snapshot.Name) -ForegroundColor Green
            }
        }
        catch {
            $rollbackErrors += ("{0}: {1}" -f $snapshot.Name, $_.Exception.Message)
            Write-Host ("  RECOVERY FAILED  {0}: {1}" -f $snapshot.Name, $_.Exception.Message) -ForegroundColor Red
        }
    }
    Write-Progress -Activity 'Automatic recovery' -Completed

    if ($rollbackErrors.Count -gt 0) {
        throw ("Apply failed: {0}`nAutomatic rollback had errors:`n{1}`nBackup: {2}" -f
            $failure.Exception.Message, ($rollbackErrors -join "`n"), $BackupDir)
    }
    throw ("Apply failed; all successfully applied values were restored. Reason: {0}`nBackup: {1}" -f
        $failure.Exception.Message, $BackupDir)
}

# Apply processor boost mode and hide selected advanced power-plan controls.
$powerCfgApplied = $false
try {
    Set-RequestedPowerBoostProfile
    $powerCfgCheck = Get-PowerCfgState
    $powerCfgVerified = ($powerCfgCheck.AcBoostMode -eq 2) -and
                        ($powerCfgCheck.DcBoostMode -eq 2) -and
                        (@($powerCfgCheck.Attributes | Where-Object { $_.Alias -in @('CPMINCORES','CPMAXCORES','PERFBOOSTMODE') -and $_.Hidden }).Count -eq 3)
    if (-not $powerCfgVerified) { throw 'Power-plan settings did not verify against the requested profile.' }
    $powerCfgApplied = $true
}
catch {
    $powerError = $_.Exception.Message
    try {
        Set-PowerCfgState -State $networkBaseline.PowerCfg
        Write-Host '  [POWER PLAN RECOVERY] Original power-plan settings restored.' -ForegroundColor Yellow
    }
    catch {
        Write-Host ("  [POWER PLAN RECOVERY FAILED] {0}" -f $_.Exception.Message) -ForegroundColor Red
    }
    Write-Host ("  [POWER PLAN WARNING] Processor boost settings were not fully applied: {0}" -f $powerError) -ForegroundColor Yellow
}

Write-Section 'PROCESSOR POWER PLAN'
if ($powerCfgApplied) {
    Write-Host '  [OK] AC processor boost mode: index 2' -ForegroundColor Green
    Write-Host '  [OK] DC processor boost mode: index 2' -ForegroundColor Green
    Write-Host '  [OK] CPMINCORES, CPMAXCORES, and PERFBOOSTMODE hidden' -ForegroundColor Green
}
else {
    Write-Host '  Power-plan changes need attention; see the warning above.' -ForegroundColor Yellow
}

# Apply conservative, supported network-stack settings after the registry profile.
$networkApplied = @()
if (-not $SkipTdrAndTcp) {
    try {
        $tcpTarget = [pscustomobject]@{ RSS = 'enabled'; AutoTuning = 'normal' }
        Set-TcpGlobalState -State $tcpTarget
        $tcpCheck = Get-TcpGlobalState
        if ($null -eq $tcpCheck -or $tcpCheck.RSS -ne 'enabled' -or $tcpCheck.AutoTuning -ne 'normal') {
            throw 'TCP global settings did not verify as RSS enabled and auto-tuning normal.'
        }
        $networkApplied += 'TCP RSS enabled'
        $networkApplied += 'TCP auto-tuning normal'
    }
    catch {
        try { Set-TcpGlobalState -State $networkBaseline.TcpGlobal } catch {
            Write-Host ("  [NETWORK RESTORE WARNING] Could not restore original TCP settings: {0}" -f $_.Exception.Message) -ForegroundColor Red
        }
        Write-Host ("  [NETWORK WARNING] TCP stack tuning was not fully applied: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
    }
}
else {
    Write-Host '  TCP registry and global TCP changes were excluded by -SkipTdrAndTcp.' -ForegroundColor DarkGray
}

# Wi-Fi "AllowComputerToTurnOffDevice" is not a supported parameter of
# Set-NetAdapterPowerManagement on this Windows NetAdapter module; leave it unchanged.

Write-Section 'NETWORK OPTIMIZATION'
if ($networkApplied.Count -gt 0) {
    foreach ($networkItem in $networkApplied) {
        Write-Host ("  [OK] {0}" -f $networkItem) -ForegroundColor Green
    }
}
else {
    Write-Host '  No additional network settings were changed.' -ForegroundColor DarkGray
}

ConvertTo-Json -InputObject @($skipped) -Depth 6 |
    Set-Content -LiteralPath (Join-Path $BackupDir 'SkippedSettings.json') -Encoding UTF8

Write-Section 'PROFILE APPLIED'
Write-Host ''
Write-Host '  SUCCESS  |  Profile application finished.' -ForegroundColor Green
Write-Host ''
Write-Status 'Successfully applied' ("{0} / {1}" -f $applied, $Changes.Count) Green
Write-Status 'Skipped' $skipped.Count $(if ($skipped.Count -gt 0) { 'Yellow' } else { 'Green' })
Write-Status 'Backup location' $BackupDir
if ($skipped.Count -gt 0) {
    Write-Host ''
    Write-Host '  Skipped settings (access denied):' -ForegroundColor Yellow
    foreach ($item in $skipped) {
        Write-Host ("    - {0}" -f $item.Name) -ForegroundColor Yellow
        if ($DetailedOutput) {
            Write-Host ("      {0}" -f $item.Reason) -ForegroundColor DarkGray
        }
    }
}
# ---------------------- IMMEDIATE POST-APPLY VERIFICATION --------------------
Write-Section 'IMMEDIATE REGISTRY VERIFICATION'
Write-Host '  Checking the registry values now, before asking about restart...' -ForegroundColor DarkGray
Write-Host ''

$immediateVerified = 0
$immediateChanged = 0
$immediateAlready = 0
$immediateFailed = 0
$immediateSkipped = 0

for ($i = 0; $i -lt $Changes.Count; $i++) {
    $item = $Changes[$i]
    $baselineItem = $Snapshots[$i]
    $percent = [int](($i + 1) * 100 / [math]::Max(1, $Changes.Count))
    Write-Progress -Activity 'Verifying registry tweaks immediately after apply' `
        -Status ("Checking {0}/{1}" -f ($i + 1), $Changes.Count) `
        -PercentComplete $percent

    $actualValue = $null
    $actualKind = $null
    $found = $false
    try {
        if (Test-Path -LiteralPath $item.Path) {
            $key = Get-Item -LiteralPath $item.Path -ErrorAction Stop
            if ($key.GetValueNames() -contains [string]$item.Name) {
                $found = $true
                $actualKind = $key.GetValueKind([string]$item.Name).ToString()
                $actualValue = $key.GetValue(
                    [string]$item.Name,
                    $null,
                    [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames
                )
            }
        }
    }
    catch {
        $found = $false
    }

    $expectedText = [string]$item.Value
    $actualText = if ($found) { [string]$actualValue } else { '<not present>' }
    $kindMatches = $found -and ($actualKind -eq [string]$item.Kind)
    $valueMatches = $found -and ($actualText -ceq $expectedText)

    if ($valueMatches -and $kindMatches) {
        $immediateVerified++
        $wasAlreadySet = $false
        if ($baselineItem.Existed) {
            $wasAlreadySet = ([string]$baselineItem.Kind -eq [string]$item.Kind) -and
                             ([string]$baselineItem.Value -ceq $expectedText)
        }

        if ($wasAlreadySet) {
            $immediateAlready++
            $status = 'ALREADY MATCHED'
            $statusColor = 'Cyan'
        }
        else {
            $immediateChanged++
            $status = 'APPLIED + VERIFIED'
            $statusColor = 'Green'
        }

        if ($DetailedOutput -and $status -eq 'APPLIED + VERIFIED') {
            Write-Host ("  [CHANGED] {0}" -f $item.Name) -ForegroundColor Green
            $beforeText = if ($baselineItem.Existed) { Format-Value $baselineItem.Value } else { '<not present>' }
            Write-Host ("       {0}  ->  {1}" -f $beforeText, $actualText) -ForegroundColor Gray
        }
        elseif ($DetailedOutput) {
            Write-Host ("  [ALREADY OK] {0}" -f $item.Name) -ForegroundColor DarkGray
        }
        if ($DetailedOutput) {
            Write-Host ("       Path: {0}" -f $item.Path) -ForegroundColor DarkGray
        }
    }
    elseif (@($skipped | Where-Object { $_.Path -eq $item.Path -and $_.Name -eq $item.Name }).Count -gt 0) {
        $immediateSkipped++
        Write-Host ("  [SKIPPED] {0} - access was denied during apply" -f $item.Name) -ForegroundColor Yellow
        if ($DetailedOutput) {
            Write-Host ("       Current: {0}" -f $actualText) -ForegroundColor DarkGray
        }
    }
    else {
        $immediateFailed++
        Write-Host ("  [NOT APPLIED] {0} | expected {1}, found {2}" -f $item.Name, $expectedText, $actualText) -ForegroundColor Red
        if ($DetailedOutput) {
            Write-Host ("       Expected type: {0}; actual type: {1}" -f $item.Kind, $actualKind) -ForegroundColor DarkGray
            Write-Host ("       Path: {0}" -f $item.Path) -ForegroundColor DarkGray
        }
    }
}
Write-Progress -Activity 'Verifying registry tweaks immediately after apply' -Completed

Write-Section 'NETWORK VERIFICATION'
$tcpNow = Get-TcpGlobalState
if ($null -ne $tcpNow) {
    Write-Status 'TCP Receive-Side Scaling' $tcpNow.RSS $(if ($tcpNow.RSS -eq 'enabled') { 'Green' } else { 'Yellow' })
    Write-Status 'TCP auto-tuning' $tcpNow.AutoTuning $(if ($tcpNow.AutoTuning -eq 'normal') { 'Green' } else { 'Yellow' })
}
else {
    Write-Status 'TCP global settings' 'Could not read' Yellow
}
Write-Section 'POWER PLAN VERIFICATION'
try {
    $powerNow = Get-PowerCfgState
    Write-Status 'Processor boost mode (AC)' $powerNow.AcBoostMode $(if ($powerNow.AcBoostMode -eq 2) { 'Green' } else { 'Yellow' })
    Write-Status 'Processor boost mode (DC)' $powerNow.DcBoostMode $(if ($powerNow.DcBoostMode -eq 2) { 'Green' } else { 'Yellow' })
    foreach ($alias in @('CPMINCORES','CPMAXCORES','PERFBOOSTMODE')) {
        $attr = @($powerNow.Attributes | Where-Object { $_.Alias -eq $alias }) | Select-Object -First 1
        Write-Status ($alias + ' hidden') ([string]$attr.Hidden) $(if ($attr.Hidden) { 'Green' } else { 'Yellow' })
    }
}
catch {
    Write-Status 'Power plan verification' $_.Exception.Message Yellow
}

Write-Section 'VERIFICATION SUMMARY'
Write-Status 'Verified' ("{0} / {1}" -f $immediateVerified, $Changes.Count) Green
Write-Status 'Changed now' $immediateChanged Green
Write-Status 'Already correct' $immediateAlready Cyan
Write-Status 'Skipped' $immediateSkipped Yellow
Write-Status 'Needs attention' $immediateFailed $(if ($immediateFailed -gt 0) { 'Red' } else { 'Green' })

if ($immediateFailed -eq 0) {
    Write-Host ''
    Write-Host '  All accessible settings match the selected profile.' -ForegroundColor Green
}
else {
    Write-Host ''
    Write-Host '  Some settings need attention. Review the items listed above.' -ForegroundColor Yellow
}

Write-Host ''
Write-Host '  Note: verification checks settings; it does not benchmark FPS or temperatures.' -ForegroundColor DarkGray
Write-Host '  After restarting, run -Verify for a second check.' -ForegroundColor DarkGray
Write-Host ''
Write-Host '  Rollback command : .\Win11-Aggressive-Performance-Final-v4-Modern-UI.ps1 -Rollback' -ForegroundColor DarkGray
Write-Host '  Recheck command  : .\Win11-Aggressive-Performance-Final-v4-Modern-UI.ps1 -Verify' -ForegroundColor DarkGray
Write-Host ''

$restartAnswer = Read-Host 'Restart Windows now? Save your work first [y/N]'
if ($restartAnswer -match '^(?i)y(es)?$') {
    Write-Host ''
    Write-Host '  Windows will restart now...' -ForegroundColor Yellow
    Start-Sleep -Seconds 3
    Restart-Computer -Force
}
else {
    Write-Host ''
    Write-Host '  Restart skipped. Restart later, then run the -Verify command above.' -ForegroundColor Yellow
    Write-Host ''
}
