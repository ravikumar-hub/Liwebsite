@echo off
setlocal
title Windows 11 Performance Center

set "LAUNCHER=%~dp0Launch-Performance.ps1"

if not exist "%LAUNCHER%" (
    echo.
    echo  Launcher file not found.
    echo  Extract the entire ZIP package before running this file.
    echo.
    pause
    exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%LAUNCHER%"

if errorlevel 1 (
    echo.
    echo  The launcher reported an error.
    pause
)
endlocal
