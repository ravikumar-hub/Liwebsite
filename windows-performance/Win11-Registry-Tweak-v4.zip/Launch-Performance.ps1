﻿#requires -Version 5.1
<#
.SYNOPSIS
  Simple menu launcher for the Windows 11 Performance Profile.
.DESCRIPTION
  Requests UAC elevation when needed, then offers Preview, Apply,
  Verify, Rollback, and Detailed Preview.
#>

$ErrorActionPreference = 'Stop'
$ProfileFile = 'Win11-Aggressive-Performance-Final-v4-Modern-UI.ps1'
$ProfilePath = Join-Path $PSScriptRoot $ProfileFile

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-Path -LiteralPath $ProfilePath)) {
    Write-Host ''
    Write-Host '  The performance profile script is missing.' -ForegroundColor Red
    Write-Host "  Expected: $ProfilePath" -ForegroundColor Yellow
    Read-Host '  Press Enter to close'
    exit 1
}

if (-not (Test-IsAdministrator)) {
    Write-Host '  Requesting Administrator permission...' -ForegroundColor Cyan
    try {
        $arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '"'
        Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') `
            -Verb RunAs -ArgumentList $arguments
    }
    catch {
        Write-Host '  Administrator approval was cancelled or could not be started.' -ForegroundColor Yellow
        Read-Host '  Press Enter to close'
    }
    exit
}

while ($true) {
    Clear-Host
    Write-Host ''
    Write-Host '  +----------------------------------------------------------+' -ForegroundColor DarkCyan
    Write-Host '  |              WINDOWS 11 PERFORMANCE                     |' -ForegroundColor Cyan
    Write-Host '  |                  QUICK LAUNCHER                          |' -ForegroundColor Gray
    Write-Host '  +----------------------------------------------------------+' -ForegroundColor DarkCyan
    Write-Host ''
    Write-Host '  Choose an operation' -ForegroundColor White
    Write-Host ''
    Write-Host '    [1]  Preview settings' -ForegroundColor Cyan
    Write-Host '    [2]  Apply performance profile' -ForegroundColor Green
    Write-Host '    [3]  Verify after restart' -ForegroundColor Cyan
    Write-Host '    [4]  Roll back changes' -ForegroundColor Yellow
    Write-Host '    [5]  Detailed preview' -ForegroundColor Gray
    Write-Host '    [0]  Exit' -ForegroundColor DarkGray
    Write-Host ''

    $choice = Read-Host '  Enter your choice'
    $switchText = $null

    switch ($choice) {
        '1' { $switchText = '-PreviewOnly' }
        '2' { $switchText = '' }
        '3' { $switchText = '-Verify' }
        '4' { $switchText = '-Rollback' }
        '5' { $switchText = '-PreviewOnly -DetailedOutput' }
        '0' { break }
        default {
            Write-Host '  Invalid choice.' -ForegroundColor Yellow
            Start-Sleep -Seconds 1
            continue
        }
    }

    if ($choice -eq '0') { break }

    Write-Host ''
    Write-Host '  Starting the selected operation...' -ForegroundColor Cyan
    Write-Host ''

    try {
        $argumentLine = '-NoProfile -ExecutionPolicy Bypass -File "' + $ProfilePath + '"'
        if (-not [string]::IsNullOrWhiteSpace($switchText)) {
            $argumentLine += ' ' + $switchText
        }

        $process = Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') `
            -ArgumentList $argumentLine -Wait -PassThru -NoNewWindow

        if ($process.ExitCode -eq 0) {
            Write-Host ''
            Write-Host '  Operation finished.' -ForegroundColor Green
        }
        else {
            Write-Host ''
            Write-Host ("  Operation returned exit code {0}." -f $process.ExitCode) -ForegroundColor Yellow
        }
    }
    catch {
        Write-Host ("  Could not start the operation: {0}" -f $_.Exception.Message) -ForegroundColor Red
    }

    Write-Host ''
    Read-Host '  Press Enter to return to the menu' | Out-Null
}

Write-Host ''
Write-Host '  Launcher closed.' -ForegroundColor Gray
