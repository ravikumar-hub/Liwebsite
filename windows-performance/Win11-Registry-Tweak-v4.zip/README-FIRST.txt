# Windows 11 Performance Center — v4

## Quick start

1. Download this ZIP package from the Windows Performance Center website.
2. Extract the entire ZIP file to a folder.
3. Double-click `START-Windows-Performance.cmd`.
4. Approve the Windows Administrator (UAC) prompt.
5. Choose **1 — Preview settings** first.
6. Choose **2 — Apply performance profile** only after reviewing the preview.
7. Restart if requested, then run **3 — Verify after restart**.

## Rollback

Run the launcher again and choose **4 — Roll back changes**. The profile uses the
backup created on that same PC. Do not copy a backup from a different PC.

## Requirements

- Windows 11 (build 22000 or later)
- Windows PowerShell 5.1
- Administrator approval

## Important notes

- Review the preview on every PC before applying.
- Experimental scheduler, GPU TDR and TCP settings are not guaranteed to improve
  FPS or latency. Different PCs and workloads can behave differently.
- Processor boost index 2 can increase heat, fan noise and battery use.
- The profile does not disable Intel thermal throttling or firmware safety protections.
- The profile limits some diagnostic/feedback collection; it does not disable all
  Windows telemetry.
- Save open work before applying; restart only when convenient.

The launcher and profile run locally. They do not upload PC data. Backups are
stored locally on each PC's Desktop.
